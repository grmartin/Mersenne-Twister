Option Strict On
Option Explicit On

Module Test_Main
	'''______________________________________________________________________________
	''' This Module was extracted from mt19937ar.vb. See the comments therein.
	''' Modified by Ron Charlton, 2008-09-23, for Visual Basic .NET.
	''' Modified by Ron Charlton, 2010-09-17 to call Diehard test data generator.
	'''______________________________________________________________________________
	Function Main() As Integer	 'int main(void)
		'Int i;
		'unsigned long init[4]={0x123, 0x234, 0x345, 0x456}, length=4;
		Dim i As Integer
		Dim init() As UInteger = {&H123, &H234, &H345, &H456}
		' We don't need length.

		Const fileName As String = "mt19937arVBTest.out"
		Const kMaxPrint As Integer = 1000 - 1
		Dim tmp As Double, s As String

		Try
			'init_by_array(init, length);
			Dim r As New MTRandom(init)

			FileOpen(1, fileName, OpenMode.Output)	   'open the output file

			'printf("1000 outputs of genrand_int32()\n");
			' To prevent alignment on tab columns, SPC() is required.
			PrintLine(1, (kMaxPrint + 1).ToString, SPC(1), "outputs of genrand_int32()")

			'for (i=0; i<1000; i++) {
			'  printf("%10lu ", genrand_int32());
			'  if (i%5==4) printf("\n");
			'}
			For i = 0 To kMaxPrint
				tmp = r.genrand_int32()

				' A space character is required at the end of the line to match the
				' original MT authors' test output.
				Print(1, String.Format("{0,10} ", tmp))	' no line ending
				If i Mod 5 = 4 Then
					PrintLine(1)	' line ending
				End If
			Next

			'printf("\n1000 outputs of genrand_real2()\n");
			PrintLine(1)
			' To prevent alignment on tab columns, SPC() is required.
			PrintLine(1, (kMaxPrint + 1).ToString, SPC(1), "outputs of genrand_real2()")

			'for (i=0; i<1000; i++) {
			'  printf("%10.8f ", genrand_real2());
			'  if (i%5==4) printf("\n");
			'}
			For i = 0 To kMaxPrint
				tmp = r.genrand_real2()

				s = Format(tmp, "0.00000000")
				' Force decimal point instead of decimal comma if needed for locale.
				s = Strings.Replace(s, ",", ".")
				' A space character is required at the end of the line to match the
				' original MT authors' test output.
				Print(1, s, SPC(1))	' no line ending
				If i Mod 5 = 4 Then
					PrintLine(1)	' line ending
				End If
			Next

			FileClose(1)	'close the output file

			Console.WriteLine("MT test output was written to file '{0}'.", fileName)


			' The following were added by Ron Charlton, and are not a part
			' of the earlier authors' Main().

			' Produce a file of random bytes for testing with John Walker's entropy
			' test program, ent.exe (at http://www.fourmilab.ch/random/).
			MakeEntropyTestData()

			' Produce a file of random 32-bit integers for testing with George Marsaglia's
			' Diehard test program, DIEHARD.EXE (at http://www.stat.fsu.edu/pub/diehard/).
			MakeDiehardData()

			' Demonstrate the MTRandom class. (It writes to file Demo.out and the
			' console.)
			Demo()

			' Run the (modified) simple performance test from the VBA version.
			SimplePerformanceTest()

		Catch ex As Exception
			Console.Error.WriteLine("{0}: {1}", _
			 My.Application.Info.AssemblyName, ex.Message)
			Console.Error.WriteLine("{0}", ex.StackTrace)
			' Prevent the window from closing in the Visual Basic .NET IDE.
			Console.Error.WriteLine("Press the <Enter> key to continue.")
			Console.ReadLine()
			Return 1
		End Try

		'return 0;
		Return 0
	End Function   'main

End Module
