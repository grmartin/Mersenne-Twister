Contents of the Mersenne Twister for Visual Basic .NET files:

FILE                        CONTENTS
------------------------    -----------------------------------------------------
mt19937ar.vb                The only file necessary to use the PRNG.  It
                            consists of one Visual Basic .NET class --
                            MTRandom -- and some exception classes used by
                            MTRandom.

Main.vb                     The original MT authors' test duplicated in VB .NET;
                            it also calls the following modules:

MakeEntropyTestData.vb      Makes a file to test with John Walker's 'ent.exe'
                            entropy and chi-squared program available at
                            http://www.fourmilab.ch/random/

MakeDiehardData.vb          Makes a file to test with George Marsaglia's
                            DIEHARD.EXE program available at
                            http://www.stat.fsu.edu/pub/diehard/

Demo.vb                     Demonstrates how to initialize and use the PRNG

SimplePerformanceTest.vb    A simple performance test

MersenneTwister.vbproj      VB Project file for Visual Basic 2010.  It likely
                            won't work with Visual Basic 2008 or 2005.  For
                            VB 2008 and 2005 make an empty console project
                            and add to it the *.vb files named above.