Option Strict On
Option Explicit On

Module SimplePerformance_Test
	' Taken from the VBA version's comments and modified by Ron Charlton
	' for Visual Basic .NET.
	' For results, see file mt19937ar.vb comments under "ON PERFORMANCE".
	Public Sub SimplePerformanceTest()
        Const kMaxNr As Integer = 100000000   'CHANGE THIS VALUE AS NEEDED
		Dim ii As Integer, sec1, sec2, delta As Double

		Dim a As New MTRandom()

		Console.WriteLine("")
		Console.WriteLine("Timing the generation of {0:E} random numbers. Please be patient.", kMaxNr)
		Console.WriteLine("Ctrl+C to interrupt...")

		sec1 = DateAndTime.Timer
        For ii = 1 To kMaxNr
            ' (assignment [=] is not required here)
            a.genrand_int32()     ' USE *ANY* ONE OF THE MTRandom FUNCTIONS
            'a.genrand_real1()
            'a.genrand_res53()
            'a.genrand_intMax(1000)
            'a.genrand_intMax(&H5FFFFFFF)
            'a.genrand_intRange(10,20)
            'a.genrand_int64()
            'a.genrand_int128SignedInt()
        Next
		sec2 = DateAndTime.Timer

		delta = sec2 - sec1

		Console.WriteLine("Elapsed time in seconds for generating {0:E} numbers: {1}", kMaxNr, delta)
		Console.Write("Nanoseconds per call: {0}.  ", delta / kMaxNr * 1000000000.0)
		Console.WriteLine("Calls per second: {0:N}.", kMaxNr / delta)

		' Prevent the window from closing in the Visual Basic .NET IDE.
		Console.WriteLine("Press the <Enter> key to continue.")
		Console.ReadLine()
	End Sub	'SimplePerformanceTest
End Module