' Ron Charlton explicitly places 'makeDiehardData.vb' in the public domain.
' It may be used for any purpose.

Option Strict On
Option Explicit On

Imports System
Imports System.IO

Module MakeDiehard_Data
	' This module makes a data file for testing with
	' George Marsaglia's Diehard software.
	' Author: Ron Charlton
    ' Date:   2011-01-31 

	Public Sub MakeDiehardData()

		' Diehard requires at least 80 million bits
		Const oneSequenceLengthInBits As Integer = 90000000
		Const oneSequenceLengthInBytes As Integer = oneSequenceLengthInBits \ 8
		Const numSequences As Integer = 1

		Dim sequence, j As Integer
		Dim ui As UInteger
		Dim data(oneSequenceLengthInBytes - 1) As Byte	' Byte is unsigned

        Dim outFileName As String = "DiehardData.out"
		Console.WriteLine("Writing MakeDiehardData.vb output to file '{0}'", outFileName)

		' delete existing output file
		If My.Computer.FileSystem.FileExists(outFileName) Then
			My.Computer.FileSystem.DeleteFile(outFileName)
		End If

		' initialize Mersenne Twister with the default value
        Dim mt As New MTRandom()

		' Append the sequences to the file one at a time.
		For sequence = 1 To numSequences

			' make a sequence of pseudorandom bits
			For j = 0 To oneSequenceLengthInBytes - 1

				' If (j Mod 4) = 0 Then get a pseudorandom number
				If (j And 3) = 0 Then ui = mt.genrand_int32()

				' x86 (little-endian) byte order
				data(j) = CByte(ui And &HFFUI)
				ui >>= 8
			Next j

			' True means Append to file
			My.Computer.FileSystem.WriteAllBytes(outFileName, data, True)

		Next sequence

		' say "file was written"
		Console.WriteLine("Done.")
		Console.WriteLine("")
		Console.WriteLine("Press the <Enter> key to continue.")
		Console.ReadLine()

	End Sub
End Module
