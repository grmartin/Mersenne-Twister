' Ron Charlton explicitly places 'Demo.vb' in the public domain.
' It may be used for any purpose.

' For versions of Visual Basic 2008 and before, set the following
' #Const to False:
#Const VB2010orLater = True

Option Strict On
Option Explicit On

Imports System
Imports System.IO
Imports System.Text ' for Encoding.UTF8
#If VB2010orLater Then
Imports System.Numerics ' for BigInteger
#End If

Module Demonstration
    ' This module demonstrates the Visual Basic .NET MTRandom class.
	' Author: Ron Charlton
    ' Date:   2012-08-16

	Public Sub Demo()
		Const demoOutputFileName As String = "Demo.out"
		'--------------------------------
        ' There are six ways to declare and initialize an MTRandom pseudo-
		' random number generator (PRNG).  Here are examples:
		'--------------------------------

		' 1) Declare a PRNG with default initialization.
        '    The default seed is 5489UI (as in the original MT authors' version).
		Dim a As New MTRandom()
		'	  -- OR --
		' Dim a As New MTRandom

        ' 2) Declare another PRNG with seed == 5489UI (the same as the default seed).
        '    Any integer seed in the range [0, 4294967295] is acceptable.
        Dim b As New MTRandom(5489UI)

		' 3) Declare a third PRNG and initialize it with an array of integers
		'	 (as in the original MT authors' test).
		Dim init() As UInteger = {&H123, &H234, &H345, &H456}
		Dim c As New MTRandom(init)

		' 4) Declare a fourth PRNG and initialize it randomly based on the
		'	 system clock (True is required but ignored)
		Dim d As New MTRandom(True)

		' 5) Declare a fifth PRNG and initialize it with a generator state
		'	 that was saved in file "myfile.xml" with MTRandom.saveState().
		'Dim e As New MTRandom("myfile.xml")	' (no such file, so commented out)

        ' 6) Declare a sixth PRNG and initialize it with good random numbers.
        '	 The Double argument is required but ignored.
        Dim f As New MTRandom(0.0)

		' send output to a file
		Using sw As StreamWriter = File.CreateText(demoOutputFileName)

			sw.WriteLine("Demo.vb output:")

			'--------------------------------
			' Generate some pseudo-random numbers:
			'--------------------------------
			' Generate random integers in the range [0, 4294967295]
			' (0 to 2^32-1).
			Dim x As UInteger = a.genrand_int32()
			Dim y As UInteger = b.genrand_int32()

			' Show that PRNGs a and b produced the same initial value, because each has
			' its own generator state and they have the same initial seed.
			sw.WriteLine("The following two numbers should be equal:")
			sw.WriteLine("x: {0}", x)
			sw.WriteLine("y: {0}", y)
			If x <> y Then
				sw.WriteLine("a.genrand_int32() and b.genrand_int32() gave different results.")
			End If

			'--------------------------------
			' Reinitialize the PRNGs. (A different initialization method
			' than used originally is acceptable on any generator.)
			'--------------------------------
			a.init_genrand(&HDD9CC370UI)
			b.init_by_array(init)
            c.init_genrand(1234987644UI)
			d.init_random(False)	' use the next initializer random number
            '							  to re-initialize MTRandom
            b.init_by_crypto(0.0)    ' restart with a cryptographically random
            '                             generator state

			'--------------------------------
			' Save a's generator state to a file named "DemoState.xml", use a some,
			' then restore a's generator to its saved state.
			'--------------------------------
			Dim loopCount As Integer
			Dim Dbl As Double
			Dim UInt As UInteger
			a.saveState("DemoState.xml")
			For loopCount = 1 To 10000
				UInt = a.genrand_int32()
			Next
			a.loadState("DemoState.xml")	' restore the existing PRNG's saved state
			'	-- OR --
			'a = New MTRandom("DemoState.xml")	' make an entirely new PRNG instance

			'--------------------------------
			' Call each of the MTRandom functions and show the result.
			'--------------------------------
			UInt = a.genrand_int32()
			sw.WriteLine("A UInteger in range [0, 4294967295]: {0}", UInt)

			Dim Int As Integer = a.genrand_int31()
			sw.WriteLine("An Integer in range [0, 2147483647] (0 to 2^31-1): {0}", Int)

			Dbl = a.genrand_real1()
			sw.WriteLine("A Double in range [0.0, 1.0] (both 0.0 and 1.0 included): {0}", Dbl)

			Dbl = a.genrand_real2()
			sw.WriteLine("A Double in range [0.0, 1.0) (0.0 included, 1.0 excluded): {0}", Dbl)

			Dbl = a.genrand_real3()
			sw.WriteLine("A Double in range (0.0, 1.0) (both 0.0 and 1.0 excluded): {0}", Dbl)

			Dbl = a.genrand_res53()
			sw.WriteLine("A Double in range [0.0, ~1.0+] = [0.0, 1.00000000721774...] (0.0 included, ~1.0 included): {0}", Dbl)

			Int = a.genrand_int32SignedInt()
			sw.WriteLine("An Integer in range [-2147483648, 2147483647] (-2^31 to 2^31-1): {0}", Int)

			Dbl = a.genrand_real2b()
			sw.WriteLine("A Double in range [0.0, 1.0) (See class MTRandom comments): {0}", Dbl)

			Dbl = a.genrand_real2c()
			sw.WriteLine("A Double in range (0.0, 1.0] (See class MTRandom comments): {0}", Dbl)

			Dbl = a.genrand_real3b()
			sw.WriteLine("A Double in range (0.0, 1.0) (See class MTRandom comments): {0}", Dbl)

			Dbl = a.genrand_real4b()
			sw.WriteLine("A Double in range [-1.0, 1.0] : {0}", Dbl)

			Dbl = a.genrand_real5b()
			sw.WriteLine("A Double in range (-1.0, 1.0) (See class MTRandom comments): {0}", Dbl)

			UInt = a.genrand_intMax(100)
			sw.WriteLine("A UInteger in range [0, 100]: {0}", UInt)

			UInt = a.genrand_intRange(0, 4000)
			sw.WriteLine("A UInteger in range [0, 4000]: {0}", UInt)

			Dim ULng As ULong = a.genrand_int64()
			sw.WriteLine("A ULong in range [0, 18446744073709551615]: {0}", ULng)

#If VB2010orLater Then
            Dim bigInt As BigInteger = a.genrand_int128SignedInt()
            sw.WriteLine("A BigInteger in range [-2^127,2^127-1]: {0}", bigInt.ToString("D"))
#End If

            ' Display the crypto values in f.state.mt(), eight to a line
            sw.WriteLine("state.mt() from f.init_by_crypto():")
            Dim m As Integer
            Dim n As Integer = 0
            For m = 0 To f.state.mt.GetUpperBound(0)
                sw.Write("{0,8:X} ", f.state.mt(m))
                If n Mod 8 = 7 Then
                    sw.WriteLine("")
                End If
                n += 1
            Next m
            sw.Close()
        End Using

		' read the file just written and display it on the console
		Console.WriteLine(File.ReadAllText(demoOutputFileName, Encoding.UTF8))

		' say "file was written" on the console
		Console.WriteLine("")
		Console.WriteLine("Demo.vb output was also written to file '{0}'.", demoOutputFileName)
		Console.WriteLine("Press the <Enter> key to continue.")
		Console.ReadLine()
	End Sub	  ' Demo

End Module
