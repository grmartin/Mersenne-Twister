MERSENNE TWISTER FOR VISUAL BASIC .NET
--------------------------------------

Date: 2012-08-19
Version 4.1 -
  o One MT19937ar.vb file now works with Visual Basic 2010, 2008 and 2005.
  o Added Sub init_by_crypto() to provide all ~2^19937 initial states.
  o Now always initializes mag01(1) = MATRIX_A.

This package contains a Visual Basic .NET class implementing the
Mersenne Twister pseudo-random number generator.  The class name is 'MTRandom'.

See 'Doc\ReadMe.htm' for help with MTRandom. It explains such things as:

  o Only one file (Source\mt19937ar.vb) from this package is needed for
    pseudo-random number generation.  It contains code and extensive
    comments.  This file may be freely distributed under certain conditions;
	see file 'COPYING.txt' for details.
  o Which file (Source\demo.vb) demonstrates in detail how to use MTRandom.
  o Performance numbers
  o How to find more information on Mersenne Twister, source code for other
    programming languages, and FAQs.
  o And much more.

The 'Source' folder contains the Mersenne Twister Visual Basic project.  See
'ReadMe.txt' therein for a brief description of the project file contents.

The 'Doc' folder contains 'ReadMe.htm' and its support files, as well as
DIEHARD test results for mt19937ar.vb.

'COPYING.txt' extracts copyright information from 'mt19937ar.vb'.

'MersenneTwister.exe' requires Microsoft .NET Framework 4.0 that comes
with Visual Basic 2010. It was built using the VB project in the 'Source'
folder.  It is a console application.  Double click it or run it from a
Command Prompt.  It will create five files in the current folder:

 o MakeEntropyTestData.out - The output from 'MakeEntropyTestData.vb'; see
                             'Source\ReadMe.txt' for a description
 o DiehardData.out         - The output from 'MakeDiehardTestData.vb'; see
                             'Source\ReadMe.txt' for a description
 o Demo.out                - The output from 'Demo.vb' (sent to the console)
 o DemoState.xml           - The saved state of a generator
 o mt19937arVBTest.out     - The output from 'Main.vb'; see
                            'Source\mt19937ar.vb' and 'Source\Main.vb'for
							details
_______________________________________________________________________________

Ron Charlton
9002 BALCOR CIR
KNOXVILLE TN  37923-2301 USA

Phone:     865-694-0800
E-mail:    charltoncr@comcast.net
Home page: http://home.comcast.net/~charltoncr/
Latest version of Mersenne Twister may always be found at:
    http://home.comcast.net/~charltoncr/#MersenneTwister

Bug reports, improvements, corrections, complaints or kudos are welcomed.

-----
Scientists study the world as it is; engineers
create the world that has never been.
    -Theodore von K�rm�n
